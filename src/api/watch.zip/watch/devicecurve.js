import request from '@/utils/request'

/**
 * 查询单条曲线
 */
export function querySingleCurve(query) {
    return request({
      url: '/mes/watch/devicecurve/querySingleCurve',
      method: 'get',
      data: query
    })
  }

export function queryCurve(query) {
    return request({
      url: '/mes/watch/devicecurve/queryCurve',
      method: 'get',
      data: query
    })
}  
