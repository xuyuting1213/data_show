// http://beziercg.lingfei.ife/qinyou-prod-api

import axios from "axios";
import qs from 'qs'
let request = '/reportapi/qinyou'
// let request = 'http://beziercg.lingfei.life/qinyou-prod-api/qinyou'
import { getToken, setToken, removeToken } from '@/utils/auth'
import { Message } from "element-ui";
// upload
export default {
    // 获取token
    async getReportToken() {
        return axios.get(request + '/ReportedData/getToken')
    },
    // 文件上传
    async uploadFile(params) {
        let res = await this.getReportToken()
        // console.log(res);
        // if (res.status == 200) {
            return axios.post('/zfapi/prod-api/web/ironWarn/store/upload', params, {
                headers: {
                    // isToken: true,
                    Authorization: res.data.data,
                    "Content-Type": "multipart/form-data"
                }
            })
        // } else {
        //     Message.error("局端获取token错误！请稍后重试！")
        // }

    },
    // /api/function/upload
    // 文件上传
    uploadFileLocal(params) {
        return axios.post('/api/function/upload', params, {
            // headers: {
            //     Authorization: getToken("Report-Token"),
            //     "Content-Type": "multipart/form-data"
            // }
        })
    },
    // web/ironWarn/store/deleteFileById
    //文件取消上传
    deleteuploadFile(params) {
        return axios.get('/api/web/ironWarn/store/deleteFileById?id=' + params.id, {
            headers: {
                Authorization: getToken("Report-Token"),
            }
        })
    },
    // ÷web/ironWarn/store/getByRelativeId
    // 文件获取id
    getFile(params) {
        return axios.get('/api/web/ironWarn/store/getByRelativeId?relativeld=' + params.relativeId, {
            headers: {
                Authorization: getToken("Report-Token"),
            }
        })
    },
    // 获取Id
    getReportId() {
        return axios.get(request + '/ReportedData/getId')
    },
    // 上报企业基础信息
    reportCompany(params) {
        return axios.post(request + '/ReportedData/ironWarn/basicCompany/updateByState', params)
    },
    // 企业基础信息获取
    readCompany() {
        // /qinyou/TbIronCompanyinfo/list
        return axios.get(request + '/TbIronCompanyinfo/1')
    },
    // 企业基础信息更新
    updateCompany(params) {
        // /qinyou/TbIronCompanyinfo/list
        return axios.put(request + '/TbIronCompanyinfo', params)
    },

    // 上报企业专项信息
    reportPersonal(params) {
        return axios.post(request + '/ReportedData/ironWarn/basicIron/saveByState', params)
    },
    // 企业专项信息获取
    readPersonal() {
        // /qinyou/TbIronCompanyinfo/list
        return axios.get(request + '/TbIronIroninfo/1', {
            headers: {
                // isToken: true,
                Authorization: 'Bearer ' + getToken('Admin-Token'),
                // "Content-Type": "multipart/form-data"
            }
        })
    },
    // 企业专项信息更新
    updatePersonal(params) {
        // /qinyou/TbIronCompanyinfo/list
        return axios.put(request + '/TbIronIroninfo', params)
    },

    // 上报设备
    reportDevice(params) {
        return axios.post(request + '/ReportedData/ironWarn/device/enterpriseSave', params)
    },
    //根据systemID获取新增修改状态
    listReportStatus(params) {
        return axios.post(request + '/ReportedData/device/state', params)
    },
    //点检根据id获取新增修改状态
    idscheckReportStatus(params) {
        return axios.post(request + '/ReportedData/supervision/checkRecord/flag', params)
    },
    //定期检验据id获取新增修改状态
    idsregularcheckReportStatus(params) {
        return axios.post(request + '/ReportedData/supervision/regularcheck/flag', params)
    },
    //停用根据id获取新增修改状态
    idsstopReportStatus(params) {
        return axios.post(request + '/ReportedData/supervision/stopworkRecord/flag', params)
    },
    //报废根据id获取新增修改状态
    idsscrabReportStatus(params) {
        return axios.post(request + '/ReportedData/supervision/scarpRecord/flag', params)
    },
    // 点检上报
    checkreportDevice(params) {
        return axios.post(request + '/ReportedData/supervision/checkRecord/save', params)
    },
    // 定期检验上报
    reugularcheckreportDevice(params) {
        return axios.post(request + '/ReportedData/supervision/regularcheck/save', params)
    },
    //停用上报
    stopreportDevice(params) {
        return axios.post(request + '/ReportedData/supervision/stopworkRecord/save', params)
    },
    //报废上报
    scrabreportDevice(params) {
        return axios.post(request + '/ReportedData/ironWarn/scarpRecord/save', params)
    },
}